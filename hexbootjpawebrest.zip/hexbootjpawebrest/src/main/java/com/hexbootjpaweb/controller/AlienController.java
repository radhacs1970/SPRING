package com.hexbootjpaweb.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.hexbootjpaweb.dao.AlienRepository;
import com.hexbootjpaweb.model.Alien;
 

@RestController
public class AlienController {
	
	@Autowired
	AlienRepository repo;
	
	//localhost:8080/h2-enabled
	
	//localhost:8080
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}
	
	@RequestMapping("/addAlien")
	public String addAlien(Alien alien) {
		System.out.println(alien);
		repo.save(alien);
		return "home.jsp";
	}
	
	@RequestMapping(path= "/alien") //, produces= {"application/xml"}
	//@ResponseBody
	public List<Alien> showAllAliens() {
		return repo.findAll();
	}
	
	
	
	@RequestMapping("/alien/{aid}")
	//@ResponseBody
	public Optional<Alien> getOneAlien(@PathVariable("aid") int aid) {
		//repo.findById(aid).orElse(null).toString();
		return repo.findById(aid);
	}

	@GetMapping(path= "/getallalien")
	//@ResponseBody
	public List<Alien> showAllAliensusingGetMapping() {
		return repo.findAll();
	}
	
	@PostMapping(path="/alien", consumes = {"application/json"})
	public Alien addNewAlien(@RequestBody Alien alien) {
		Alien a = repo.save(alien);
		return a;
	}
	
	@PutMapping(path="/alien", consumes = {"application/json"})
	public Alien saveorupdatealien(@RequestBody Alien alien) {
		Alien a = repo.save(alien);
		return a;
	}
	
	@DeleteMapping("alien/{aid}")
	public String deleteAlien(@PathVariable("aid") int aid) {
		Alien a = repo.findById(aid).orElse(null);
		if ( a != null)
			repo.delete(a);
		
		return "deleted";
	}
}
