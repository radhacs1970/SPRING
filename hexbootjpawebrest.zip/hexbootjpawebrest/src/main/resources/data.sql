insert into Alien(Aid, aname, tech) values(101, 'srijanani', 'java');
insert into Alien(Aid, aname, tech) values(102, 'ram', 'Angular');
insert into Alien(Aid, aname, tech) values(103, 'krishnan', 'java');
insert into Alien(Aid, aname, tech) values(104, 'geetha', 'Angular');
insert into Alien(Aid, aname, tech) values(105, 'meena', 'python');