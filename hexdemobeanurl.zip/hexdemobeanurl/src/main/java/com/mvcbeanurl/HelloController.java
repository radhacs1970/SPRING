package com.mvcbeanurl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class HelloController extends AbstractController {

	String greet;
	
	public String getGreet() {
		return greet;
	}

	public void setGreet(String greet) {
		this.greet = greet;
	}

	@Override
	protected ModelAndView handleRequestInternal(
			HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		System.out.println(getGreet());
		ModelAndView mv = new ModelAndView("hello") ;
		mv.addObject("message", "Good Learning Spring Framework");
		mv.addObject("message2", getGreet());
		return mv;
	}

}
