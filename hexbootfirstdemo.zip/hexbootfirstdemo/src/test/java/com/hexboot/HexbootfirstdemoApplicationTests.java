package com.hexboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexbootfirstdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
