package com.hexboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class HexbootfirstdemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =
				SpringApplication.run(HexbootfirstdemoApplication.class, args);
		System.out.println("Welcome...");
		 
//		Alien a = context.getBean(Alien.class);
//		a.setName("Mala");
//		a.show();
//		
//		Alien b = context.getBean(Alien.class);
//		b.show();
		
		//Alien di = context.getBean(Alien.class);
		//di.setName("Meena");
		//di.show();
		
		// assigning values using setter methods.
		Alien divalue = context.getBean(Alien.class);
		divalue.show();
	}

}
