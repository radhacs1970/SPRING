package com.hexboot;

import org.springframework.stereotype.Component;

@Component("samlap")
public class Laptop {
	private int lid;
	private String brand;
	
	public Laptop() {
		lid= 10;
		brand= "Samsung";
	}
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	@Override
	public String toString() {
		return "Laptop [lid=" + lid + ", brand=" + brand + "]";
	}
	public void compile() {
		System.out.println("doing compilation " + this.toString());
	}
	

}
