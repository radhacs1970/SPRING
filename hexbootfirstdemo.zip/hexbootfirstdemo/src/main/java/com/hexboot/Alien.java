package com.hexboot;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

// scope - singleton, prototype, request, session, application
@Component
@Scope("singleton")
//@Lazy
public class Alien {
	
	@Value("${Alien.aid}")
	private int aid;
	
	@Value("${Alien.name}")
	private String name;
	
	@Value("${Alien.tech}")
	//@Value("jsp")
	private String tech;
	
	@Autowired
	@Qualifier("samlap")
	private Laptop laptop;
	
	
	public Alien(){
		System.out.println(" Alien - in constructor");
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	
	public void show() {
		System.out.println(" ALIEN Object created and being displayed...");
		System.out.println(" alien id is " + getAid());
		System.out.println(" alien name is " + getName());
		System.out.println(" alien tech is " + getTech());
		laptop.compile();
	}
	@PostConstruct
	public void init() {
		System.out.println("after constructor...");
	}
	@PreDestroy
	public void destroy() {
		System.out.println(" Closing the bean");
	}
}
