package hexmvcdemodb.Dao;

import java.util.List;

import hexmvcdemodb.model.Emp;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmpDao {
	
	JdbcTemplate template;

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public List<Emp> getAllEmployees(){
		String sql = "Select * from Emp99";
		EmpRowMapper erm = new EmpRowMapper();
		List<Emp> emplist = 
					template.query(sql, erm);
		
		return emplist;
	}
	

}
