package com.mvcannotate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mvcannotate.service.AddService;

@Controller
public class AddController {
	
	@RequestMapping(value= "add", method=RequestMethod.POST)
	public ModelAndView add( @RequestParam("t1") int t1, @RequestParam("t2") int t2 ){
		ModelAndView mv = new ModelAndView();
		System.out.println(" inside controller");
		AddService as = new AddService();
		int k = as.add(t1, t2);
		mv.addObject("result", k);
		mv.setViewName("show");
		return mv;
		
	}
	

	//http://localhost:8081/hexmvcdemotwo/path/100
	@RequestMapping("path/{id}")
	public ModelAndView showpathvariableInfo(@PathVariable("id") int id){
		ModelAndView mv = new ModelAndView();
		System.out.println(" inside controller showpathvariableInfo " + id);
		
		mv.addObject("pv", id);
		mv.setViewName("pathvariable");
		return mv;
	}

}
