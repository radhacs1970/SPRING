package hexdemo.aaJdbcEx.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import hexdemo.aaJdbcEx.model.Employee;

public class EmployeeMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		 Employee emp = new Employee();
		 
		 
		 int em = rs.getInt("empid");
		 emp.setId(em);
		 
		 emp.setName(rs.getString("name"));
		 emp.setRole(rs.getString("role"));
		return emp;
	}

}
