package hexdemo.aaJdbcEx.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import hexdemo.aaJdbcEx.model.Employee;

public class EmployeeDAOJDBCTemp implements EmployeeDAO {
	private DataSource dataSource;
   private JdbcTemplate jdbcTemplateObject;
   
   public void setDataSource(DataSource dataSource) {
      this.dataSource = dataSource;
      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
   }

	@Override
	public void save(Employee employee) {
		String query = "insert into Employee (empid, name, role) values (?,?,?)";
		jdbcTemplateObject.update( query, employee.getId(),employee.getName(),employee.getRole());
		 return;
	}

	@Override
	public Employee getById(int id) {
		String query = "select * from Employee where empid = ?";
		 
		Employee emp = jdbcTemplateObject.queryForObject(query, 
		         new Object[]{id}, 
		         new EmployeeMapper());
		     
		return emp;      
	}

	@Override
	public void update(Employee employee) {
		String query = "update Employee set name=?, role=? where empid=?";
	      jdbcTemplateObject.update(query,employee.getName(),employee.getRole(),employee.getId()  );
	      System.out.println("Updated Record with ID = " + employee.getId() );
	      return;
		
	}

	@Override
	public void deleteById(int id) {
		String query = "delete from Employee where empid = ?";
	      jdbcTemplateObject.update(query, id);
	      System.out.println("Deleted Record with ID = " + id ); 
		
	}

	@Override
	public List<Employee> getAll() {
		String query = "select * from Employee";
		List <Employee> empList = jdbcTemplateObject.query(query, new EmployeeMapper());
	    return empList;
	}
}
