package hexdemo.aaJdbcEx.primaryex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ComponentScan("hexdemo.aaJdbcEx.primaryex")
public class AppConfigForPrimary {
  
  @Bean
  public Animal tigerBean() {
    return new Animal("Tiger");
  }
  
  @Bean
  @Primary
  public Animal kangarooBean() {
    return new Animal("Kangaroo");
  }
  
  @Bean
  public Animal foxBean() {
    return new Animal("Fox");
  }
   
}