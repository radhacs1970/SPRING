package hexdemo.aaJdbcEx.primaryex;

import org.springframework.beans.factory.annotation.Autowired;

public class PrimaryDITestBean {

	  @Autowired
	  private Animal animal;

	  public void printAnimal() {
	    System.out.println(animal);
	  }

	   
	}