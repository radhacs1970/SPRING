package hexdemo.aaJdbcEx.primaryex;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ApplicationPrimaryDemo {

	  public static void main(String[] args) {
	    ApplicationContext ctxt = new AnnotationConfigApplicationContext(hexdemo.aaJdbcEx.primaryex.AppConfigForPrimary.class);

	    PrimaryDITestBean pdits = ctxt.getBean(hexdemo.aaJdbcEx.primaryex.PrimaryDITestBean.class);
	    pdits.printAnimal();
	                
	  }
	}