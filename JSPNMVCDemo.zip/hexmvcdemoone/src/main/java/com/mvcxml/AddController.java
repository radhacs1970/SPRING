package com.mvcxml;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AddController {
	
	/*
	 * @RequestMapping("add")
	public String  add(HttpServletRequest request,
						HttpServletResponse response){
		System.out.println(" adding two number ");
		int i = Integer.parseInt(request.getParameter("t1"));
		int j = Integer.parseInt(request.getParameter("t2"));
		int k =i +j;
		request.setAttribute("result", k);
		return "show.jsp";
	}
	*/
	
	@RequestMapping("add" )
	public ModelAndView  add(HttpServletRequest request,
						HttpServletResponse response){
		System.out.println(" adding two number ");
		int i = Integer.parseInt(request.getParameter("t1"));
		int j = Integer.parseInt(request.getParameter("t2"));
		int k =i +j;
		ModelAndView mv = new ModelAndView();
		mv.addObject("result", k);
		mv.setViewName("show.jsp");
		mv.addObject("MyTrainerName", "radha");
		return mv; 	
	}
	

}
//yuvarajveeramallu888@gmail.com