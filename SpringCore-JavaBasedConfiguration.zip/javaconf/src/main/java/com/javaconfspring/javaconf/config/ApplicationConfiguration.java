package com.javaconfspring.javaconf.config;

 
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.javaconfspring.javaconf.model.Country;
 
@Configuration
public class ApplicationConfiguration {
 
 @Bean(name="countryObj")
 public Country getCountry()
 {
  return new Country("India");
 }
 
}