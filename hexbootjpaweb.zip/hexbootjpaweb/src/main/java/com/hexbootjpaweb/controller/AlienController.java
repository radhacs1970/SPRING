package com.hexbootjpaweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.hexbootjpaweb.dao.AlienRepository;
import com.hexbootjpaweb.model.Alien;
 

@Controller
public class AlienController {
	
	@Autowired
	AlienRepository repo;
	
	//localhost:8080/h2-enabled
	
	//localhost:8080
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}
	
	@RequestMapping("/addAlien")
	public String addAlien(Alien alien) {
		System.out.println(alien);
		repo.save(alien);
		return "home.jsp";
	}
	
	@RequestMapping("/alien")
	@ResponseBody
	public String showAllAliens() {
		return repo.findAll().toString();
	}
	
	@RequestMapping("/alien/{aid}")
	@ResponseBody
	public String getOneAlien(@PathVariable("aid") int aid) {
		//repo.findById(aid).orElse(null).toString();
		return repo.findById(aid).toString();
	}
	
	@RequestMapping("/getalien")
	public ModelAndView getAlien(@RequestParam int aid) {
		 ModelAndView mv = new ModelAndView("showAlien.jsp");
		 Alien alien = repo.findById(aid).orElse(new Alien());
		 mv.addObject(alien);
		 
		 List<Alien> al = repo.findByTech("Angular");
		 for (Alien a : al) {
		      System.out.println(a);
		 }
		 System.out.println("------------");
		 List<Alien> alf = repo.findByAidGreaterThan(102);
		 for (Alien a : alf) {
		      System.out.println(a);
		 }
		 
		 System.out.println("------------");
		 List<Alien> alt = repo.findByTechSorted("java");
		 for (Alien a : alt) {
		      System.out.println(a);
		 }
		 
		 
		return mv;
	}

}
