package com.hexbootjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexbootjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
