package com.hexbootjpa;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.hexbootjpa.dao.CustomerRepository;
import com.hexbootjpa.model.Customer;

@SpringBootApplication
public class HexbootjpaApplication {

	private static final Logger log = 
			 LoggerFactory.getLogger(HexbootjpaApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(HexbootjpaApplication.class, args);
	}
	
	@Bean
	  public CommandLineRunner demo(CustomerRepository repository) {
	    return (args) -> {
	      // save a few customers
	      repository.save(new Customer("Jack", "Gupta"));
	      repository.save(new Customer("Chloe", "Reddy"));
	      repository.save(new Customer("Kim", "Gupta"));
	      repository.save(new Customer("David", "Iyer"));
	      repository.save(new Customer("Michelle", "khan"));

	      // fetch all customers
	      log.info("Customers found with findAll():");
	      log.info("-------------------------------");
	      for (Customer customer : repository.findAll()) {
	        log.info(customer.toString());
	      }
	      log.info("");

	      // fetch an individual customer by ID
	      Customer customer = repository.findById(1L);
	      log.info("Customer found with findById(1L):");
	      log.info("--------------------------------");
	      log.info(customer.toString());
	      log.info("");

	      // fetch customers by last name
	      log.info("Customer found with findByLastName('Gupta'):");
	      log.info("--------------------------------------------");
//	      repository.findByLastName("Gupta").forEach(bauer -> {
//	        log.info(bauer.toString());
//	      });
	      for (Customer g : repository.findByLastName("Gupta")) {
	      log.info(g.toString());
	      }
	      log.info("");
	      
	      
	      //
	      
	   // fetch customers by last name
//	      log.info("Customer found with findcust :- ");
//	      log.info("--------------------------------------------");
//
//	      for (Customer g : repository.findcust( )) {
//	      log.info(g.toString());
//	      }
//	      log.info("");
	    };
	  }
}
