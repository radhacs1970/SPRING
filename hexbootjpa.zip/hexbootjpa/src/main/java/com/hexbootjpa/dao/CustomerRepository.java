package com.hexbootjpa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.hexbootjpa.model.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
	List<Customer> findByLastName(String lastName);
	Customer findById(long id);
	
	//@Query("lastName Like 'g%' and firstname Like 'J%'")
	//List<Customer> findcust();
}
