package hexmvcdemodb;

import java.util.List;

import hexmvcdemodb.Dao.EmpDao;
import hexmvcdemodb.model.Emp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
 
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmpController {
	
	@Autowired
	EmpDao empdao;
	
	// show the list of employees. viewform
	@RequestMapping("viewform")
	public String viewAllEmp(Model m){
		List<Emp> listemp = empdao.getAllEmployees();
		m.addAttribute("list", listemp);
		return "viewemp";		
	}
	
	@RequestMapping(value ="save", method=RequestMethod.POST)
	public String save(@ModelAttribute("emp") Emp emp){
		empdao.save(emp);
		return "redirect:/viewform";
	}
	
	@RequestMapping("empform")
	public String showEmpForm(Model m){
		m.addAttribute("command",new Emp());
		return "empform";
	}
	
	@RequestMapping(value="editemp/{id}")
	public String edit(@PathVariable int id, Model m){
		Emp emp = empdao.getEmpById(id);
		m.addAttribute("command", emp);
		return "empeditform";
	}
	
	@RequestMapping(value ="editsave", method=RequestMethod.POST)
	public String editsave(@ModelAttribute("emp") Emp emp){
		empdao.update(emp);
		return "redirect:/viewform";
	}
	
	@RequestMapping(value="deleteemp/{id}")
	public String deleteemp(@PathVariable int id){
		 empdao.deletemp(id);
		 
		return "redirect:/viewform";
	}
}
