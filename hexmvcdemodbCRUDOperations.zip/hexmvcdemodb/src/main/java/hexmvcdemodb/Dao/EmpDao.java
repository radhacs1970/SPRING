package hexmvcdemodb.Dao;

import java.util.List;

import hexmvcdemodb.model.Emp;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmpDao {
	
	JdbcTemplate template;

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public int save(Emp emp){
		int result = 0;
		//insert into Emp99(name,salary,designation) values('baba ji',988888.0, 'CEO'
		String sql = "insert into Emp99(name,salary,designation) values('"
					+ emp.getName()+"',"
					+ emp.getSalary() + ", '"
					+ emp.getDesignation() + "') ";
		System.out.println(sql);
	    result = template.update(sql);					
		return result;
	}
	public List<Emp> getAllEmployees(){
		String sql = "Select * from Emp99";
		
		EmpRowMapper erm = new EmpRowMapper();
		List<Emp> emplist = 
					template.query(sql, erm);
		
		return emplist;
	}
	public Emp getEmpById(int id ){
		String sql = "Select * from Emp99 where id = ?";
		EmpRowMapper erm = new EmpRowMapper();
		Emp emp = template.queryForObject(sql, new Object[]{id}, erm);
		return emp;
	}
	
	public int update( Emp emp ){
		String sql = "Update Emp99 set name = '"+ emp.getName()+
					"' , salary= "+ emp.getSalary() + 
					 ", designation = ' "+ emp.getDesignation() + 
					 "' where id=" + emp.getId() + "";
		System.out.println(sql);
		int result = template.update(sql);
		return result;
	}
	
	public int deletemp( int id ){
		String sql = " delete from emp99 where id= " + id + " ";
		return template.update(sql);
	}
}
