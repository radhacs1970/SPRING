package hexmvcdemodb.Dao;

import hexmvcdemodb.model.Emp;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;



public class EmpRowMapper implements RowMapper<Emp> {

	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Emp emp = new Emp();
		emp.setId(rs.getInt("id"));
		emp.setName(rs.getString("name"));
		emp.setSalary(rs.getFloat("salary"));
		emp.setDesignation(rs.getString("designation"));
		
		return emp;
	}

}
