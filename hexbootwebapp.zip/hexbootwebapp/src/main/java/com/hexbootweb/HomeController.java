package com.hexbootweb;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	/*
	 * @RequestMapping("myhome") 
	 * public String home() {
	 * System.out.println(" inside the controler method home"); 
	 * return "home.jsp"; 
	 * }
	 */
		
	/*
	 * @RequestMapping("myhome")
	 * @ResponseBody // displays the returns string in the browser.. public String
	 * home() { 
	 * System.out.println(" inside the controler method home"); 
	 * return	"hello all"; 
	 * }
	 */
	
	// http://localhost:8080/myhome?name=radha
	/*
	 * @RequestMapping("myhome") 
	 * public String home(HttpServletRequest req, HttpSession sess ) 
	 * { 
	 * System.out.println(" inside the controler method home");
	 * String name = req.getParameter("name"); 
	 * req.setAttribute("name", name);
	 * sess.setAttribute("ssname", name); 
	 * return "home.jsp"; 
	 * }
	 */
	
//	@RequestMapping("myhome")
//	public String home( @RequestParam("name") String name, HttpSession sess) {
//		System.out.println(" inside the controler method home");	 
//		sess.setAttribute("ssname", name);
//		return "home.jsp";		
//	}
	
//	@RequestMapping("myhome")
//	public ModelAndView home( @RequestParam("name") String name, HttpSession sess) {
//		System.out.println(" inside the controler method home");	 
//		sess.setAttribute("ssname", name);
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("home.jsp");
//		mv.addObject("name", name);
//		return mv;		
//	}
	
	
//	@RequestMapping("myhome")
//	public ModelAndView home( @RequestParam("name") String name ) {
//		System.out.println(" inside the controler method home");	 
//		 
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("home");
//		mv.addObject("name", name);
//		return mv;		
//	}
	
	//http://localhost:8081/home?aid=1&aname=radha&tech=java
	
	@RequestMapping("myhome")
	public ModelAndView home( Alien alien ) {
		System.out.println(" inside the controler method home");	 
		 
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		mv.addObject("obj", alien);
		return mv;		
	}
}
