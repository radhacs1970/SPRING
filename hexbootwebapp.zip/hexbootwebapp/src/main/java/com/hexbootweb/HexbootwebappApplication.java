package com.hexbootweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexbootwebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(HexbootwebappApplication.class, args);
	}

}
